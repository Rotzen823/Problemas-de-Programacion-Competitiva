#include <bits/stdc++.h>
#define MAX 70
 
using namespace std;

char page[MAX][MAX];
string c5[30][5] = {{".***..", "*...*.", "*****.", "*...*.", "*...*."}, {"****..", "*...*.", "****..", "*...*.", "****.."}, 
{".****.", "*...*.", "*.....", "*.....", ".****."}, {"****..", "*...*.", "*...*.", "*...*.", "****.."}, 
{"*****.", "*.....", "***...", "*.....", "*****."}, {"*****.", "*.....", "***...", "*.....", "*....."},
{".****.", "*.....", "*..**.", "*...*.", ".***.."}, {"*...*.", "*...*.", "*****.", "*...*.", "*...*."},
{"*****.", "..*...", "..*...", "..*...", "*****."}, {"..***.", "...*..", "...*..", "*..*..", ".**..."},
{"*...*.", "*..*..", "***...", "*..*..", "*...*."}, {"*.....", "*.....", "*.....", "*.....", "*****."},
{"*...*.", "**.**.", "*.*.*.", "*...*.", "*...*."}, {"*...*.", "**..*.", "*.*.*.", "*..**.", "*...*."},
{".***..", "*...*.", "*...*.", "*...*.", ".***.."}, {"****..", "*...*.", "****..", "*.....", "*....."},
{".***..", "*...*.", "*...*.", "*..**.", ".****."}, {"****..", "*...*.", "****..", "*..*..", "*...*."},
{".****.", "*.....", ".***..", "....*.", "****.."}, {"*****.", "*.*.*.", "..*...", "..*...", ".***.."},
{"*...*.", "*...*.", "*...*.", "*...*.", ".***.."}, {"*...*.", "*...*.", ".*.*..", ".*.*..", "..*..."},
{"*...*.", "*...*.", "*.*.*.", "**.**.", "*...*."}, {"*...*.", ".*.*..", "..*...", ".*.*..", "*...*."},
{"*...*.", ".*.*..", "..*...", "..*...", "..*..."}, {"*****.", "...*..", "..*...", ".*....", "*****."}};

void c1P(int x, int y, string pal){
    int lar = pal.length();
    int lim = min(61, y + lar );
    for(int k = y, j = 0; k < lim; k++, j++){
        if(pal[j] == ' '){
            continue;
        }
        page[x][k] = pal[j];
    }
}

void c5P(int x, int y, string pal){
    int st = y;
    for(int i = 0; i < pal.length(); i++){
        int let = pal[i] - 'A';
        if(pal[i] == ' '){
            st += 6;
            if(st > 60){
                break;
            }
            continue;
        }  
        
        int lim = min(x + 5, 61); 
        for(int k = x, k2 = 0; k < lim; k++, k2++){
            int lim2 = min(st + 6, 61);
            for(int j = st, j2 = 0; j < lim2; j++, j2++){
                if(c5[let][k2][j2] == '.'){
                    continue;
                }
                page[k][j] = c5[let][k2][j2];
            }
        }

        st += 6;
        if(st > 60){
            break;
        }
    } 
}

void c1C(int x, string pal){
    int lim = pal.length();
    if(lim > 60){
        int st = (lim - 60) / 2;
        pal = pal.substr(st, 60);
        c1P(x, st, pal);
    }
    else{
        int st = (60 - lim) / 2 + 1;
        if(lim & 1){
            st++;
        }
        c1P(x, st, pal);
    }
}

void c5C(int x, string pal){
    int lim = pal.length() * 6;
    if(lim > 60){
        int st = (lim - 60) / 6;
        if(st & 1){
            st = st / 2;
            int let = pal[st] - 'A';
            if(pal[st] != ' '){
                int lim = min(61, x + 5);
                for(int k = x, k2 = 0; k < lim; k++, k2++){
                    for(int j = 1, j2 = 3; j <= 3; j++, j2++){
                        if(c5[let][k2][j2] == '.'){
                            continue;
                        }
                        page[k][j] = c5[let][k2][j2];
                    }
                }
            }

            pal = pal.substr(st + 1, 11);
            c5P(x, 4, pal);
        }
        else{
            st = st / 2;
            pal = pal.substr(st, 10);
            c5P(x, 1, pal);
        }
    }
    else{
        int st = (60 - lim) / 2 + 1;
        c5P(x, st, pal);
    }
}

void c1R(int x, string pal){
    int lim = pal.length();

    if(lim > 60){
        int st = lim - 60;
        pal = pal.substr(st, 60);
        c1P(x, 1, pal);
    }
    else{
        int st = 60 - lim + 1;
        c1P(x, st, pal);
    }
}

void c5R(int x, string pal){
    int lim = pal.length() * 6;

    if(lim > 60){
        int st = (lim - 60) / 6;
        pal = pal.substr(st, 10);
        c5P(x, 1, pal);
    }
    else{
        int st = 60 - lim + 1;
        c5P(x, st, pal); 
    }
}

int main() {
    string op, fuente, sentence;
    int x, y;
    char ax;

    for(int k = 1; k <= 60; k++){
        for(int j = 1; j <= 60; j++){
            page[k][j] = '.';
        }
    }

    while(cin >> op){
        if(op == ".EOP"){
            for(int k = 1; k <= 60; k++){
                for(int j = 1; j <= 60; j++){
                    printf("%c", page[k][j]);
                    page[k][j] = '.';
                }
                printf("\n");
            }
            printf("\n");
            for(int k = 0; k < 60; k++){
                printf("-");
            }
            printf("\n\n");
        }
        else if(op == ".P"){
            cin >> fuente >> x >> y;
            scanf("%c", &ax);
            getline(cin, sentence);
            sentence = sentence.substr(1, sentence.length() - 2);
            if(fuente == "C1"){
                c1P(x, y, sentence);
            }
            else{
                c5P(x, y, sentence);
            }
        }
        else if(op == ".C"){
            cin >> fuente >> x;
            scanf("%c", &ax);
            getline(cin, sentence);
            sentence = sentence.substr(1, sentence.length() - 2);
            if(fuente == "C1"){
                c1C(x, sentence);
            }
            else{
                c5C(x, sentence);
            }
        }
        else if(op == ".L"){
            cin >> fuente >> x;
            scanf("%c", &ax);
            getline(cin, sentence);
            sentence = sentence.substr(1, sentence.length() - 2);
            if(fuente == "C1"){
                c1P(x, 1, sentence);
            }
            else{
                c5P(x, 1, sentence);
            }
        }
        else if(op == ".R"){
            cin >> fuente >> x;
            scanf("%c", &ax);
            getline(cin, sentence);
            sentence = sentence.substr(1, sentence.length() - 2);
            if(fuente == "C1"){
                c1R(x, sentence);
            }
            else{
                c5R(x, sentence);
            }
        }
    }
    
    return 0;
}