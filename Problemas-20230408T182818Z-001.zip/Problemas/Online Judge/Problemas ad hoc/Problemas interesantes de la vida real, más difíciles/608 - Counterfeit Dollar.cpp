#include <bits/stdc++.h>
 
using namespace std;


int main() {
    int n;
    scanf("%d", &n);

    while(n--){
        string izq, der, op;
        int monedas[] = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
        for(int k = 0; k < 3; k++){
            
            cin >> izq >> der >> op;

            if(op == "even"){
                for(char ax : izq){
                    monedas[ax - 'A'] = 0; 
                }

                for(char ax : der){
                    monedas[ax - 'A'] = 0; 
                }
            }
            else{
                int i = -1, d = 1;
                bool noBal[12] = {0};
                if(op == "up"){
                    i = 1;
                    d = -1;
                }
                for(char ax : izq){
                    noBal[ax - 'A'] = true;
                    if(monedas[ax - 'A'] == 0){
                        continue;
                    }

                    if(monedas[ax - 'A'] == d){
                        monedas[ax - 'A'] = 0;
                    }
                    else{
                        monedas[ax - 'A'] = i;
                    }
                }

                for(char ax : der){
                    noBal[ax - 'A'] = true;
                    if(monedas[ax - 'A'] == 0){
                        continue;
                    }

                    if(monedas[ax - 'A'] == i){
                        monedas[ax - 'A'] = 0;
                    }
                    else{
                        monedas[ax - 'A'] = d;
                    }
                }

                for(int k = 0; k < 12; k++){
                    if(!noBal[k]){
                        monedas[k] = 0;
                    }
                }
            }
        } 

        for(int k = 0; k < 12; k++){
            if(monedas[k] == 1 || monedas[k] == -1){
                printf("%c is the counterfeit coin and it is ", k + 'A');
                monedas[k] == 1 ? printf("heavy.\n") : printf("light.\n");
                break;
            }
        }
    }
    
    return 0;
}