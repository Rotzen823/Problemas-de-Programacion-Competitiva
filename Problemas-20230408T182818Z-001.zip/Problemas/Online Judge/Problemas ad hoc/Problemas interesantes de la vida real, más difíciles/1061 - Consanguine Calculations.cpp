#include <bits/stdc++.h>
 
using namespace std;

void mostrar(set<string> res){
    bool bandera = false;
    if(res.size() == 0){
        cout << "IMPOSSIBLE";
        return;
    }
    else if(res.size() == 1){
        cout << (*res.begin());
        return;
    }
    printf("{");
    for(auto x : res){
        if(bandera){
            printf(", ");
        }
        bandera = true;
        cout << x;
    }
    printf("}");
}

void mostrar2(string res){
    cout << res;
}

int main() {
    string p1 = "", p2 = "", ch = "", r;
    int c = 1;

    while(cin >> p1 >> p2 >> ch, !(p1 == "E" && p2 == "N" && ch == "D")){
        set<string> res;
        vector<char> c1;
        bool pos = false;

        string ax = p1;
        if(p1 == "?"){
            ax = p2;
        }


        if(ax[0] == 'A' && ax[1] == 'B'){
            c1.push_back('A');
            c1.push_back('B');
            if(ax[2] == '+'){
                pos = true;
            }
        }
        else{
            c1.push_back('O');
            if(ax[1] == '+'){
                pos = true;
            }
            if(ax[0] == 'A'){
                c1.push_back('A');
            }
            else if(ax[0] == 'B'){
                c1.push_back('B');
            }
        }

        if(ch == "?"){
            vector<char> c2;
            if(p2[0] == 'A' && p2[1] == 'B'){
                c2.push_back('A');
                c2.push_back('B');
                if(p2[2] == '+'){
                    pos = true;
                }
            }
            else{
                c2.push_back('O');
                if(p2[1] == '+'){
                    pos = true;
                }

                if(p2[0] == 'A'){
                    c2.push_back('A');
                }
                else if(p2[0] == 'B'){
                    c2.push_back('B');
                }
            }

            for(auto x : c1){
                for(auto y : c2){
                    if(x == y || y == 'O'){
                        r = "";
                        r.push_back(x);
                        r = r + "-";
                        if(!res.count(r)){
                            res.insert(r);
                        }

                        r = "";
                        r.push_back(x);
                        r = r + "+";
                        if(pos && !res.count(r)){
                            res.insert(r);
                        }
                    }
                    else if(x == 'O'){
                        r = "";
                        r.push_back(y);
                        r = r + "-";

                        if(!res.count(r)){
                            res.insert(r);
                        }

                        r = "";
                        r.push_back(y);
                        r = r + "+";
                        if(pos && !res.count(r)){
                            res.insert(r);
                        }
                    }
                    else if((x == 'A' && y == 'B') || (y == 'A' && x == 'B')){
                        if(!res.count("AB-")){
                            res.insert("AB-");
                        }

                        if(pos && !res.count("AB+")){
                            res.insert("AB+");
                        }
                    }
                }
            }
        }
        else{
            vector<string> c2;
            bool posCh = false;
            if(ch[0] == 'A' && ch[1] == 'B'){
                c2.push_back("AB");
                if(ch[2] == '+'){
                    posCh = true;
                }
            }
            else{
                r = ch.substr(0, 1) + "O";
                c2.push_back(r);
                if(ch[1] == '+'){
                    posCh= true;
                }

                if(ch[0] != 'O'){
                    r = ch.substr(0, 1) + ch.substr(0, 1);
                    c2.push_back(r);
                }
            }

            for(auto x : c1){
                for(auto y : c2){
                    if(x == y[0] || x == y[1]){
                        if(x == y[1]){
                            swap(y[0], y[1]);
                        }

                        if((y[1] == 'A' || y[1] == 'B')){
                            if(!res.count("AB+")){
                                res.insert("AB+");
                            }

                            if(!(!pos && posCh) && !res.count("AB-")){
                                res.insert("AB-");
                            }
                        }
                        
                        if(y[1] == 'B' || y[1] == 'O'){
                            if(!res.count("B+")){
                                res.insert("B+");
                            }

                            if(!(!pos && posCh) && !res.count("B-")){
                                res.insert("B-");
                            }
                        }

                        if(y[1] == 'A' || y[1] == 'O'){
                            if(!res.count("A+")){
                                res.insert("A+");
                            }

                            if(!(!pos && posCh) && !res.count("A-")){
                                res.insert("A-");
                            }
                        }
                        
                        if(y[1] == 'O'){
                            if(!res.count("O+")){
                                res.insert("O+");
                            }

                            if(!(!pos && posCh) && !res.count("O-")){
                                res.insert("O-");
                            }
                        }
                    }
                }
            }
        }

        printf("Case %d: ", c++);

        p1 == "?" ? mostrar(res) : mostrar2(p1);
        printf(" ");
        
        p2 == "?" ? mostrar(res) : mostrar2(p2);
        printf(" ");

        ch == "?" ? mostrar(res) : mostrar2(ch);
        printf("\n");
    }
    
    return 0;
}