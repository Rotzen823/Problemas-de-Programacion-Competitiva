import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n;
		int fecha, d, m, a;
		
		n = sc.nextInt();
		
		for(int k = 1; k <= n; k++) {
			fecha = sc.nextInt();
			a = fecha % 10000;
			fecha /= 10000;
			
			d = fecha % 100;
			m = fecha / 100;
			
			Calendar c = GregorianCalendar.getInstance();
			c.set(a, m - 1, d + 280);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			//System.out.println(m + " " + d);
			m = c.getTime().getMonth() + 1;
			d = c.getTime().getDate();
			System.out.print(k + " " + sdf.format(c.getTime()) + " ");
			
			if((m == 1 && d >= 21) || (m == 2 && d <= 19)) {
				System.out.print("aquarius");
			}
			else if((m == 2 && d >= 20) || (m == 3 && d <= 20)) {
				System.out.print("pisces");
			}
			else if((m == 3 && d >= 21) || (m == 4 && d <= 20)) {
				System.out.print("aries");
			}
			else if((m == 4 && d >= 21) || (m == 5 && d <= 21)) {
				System.out.print("taurus");
			}
			else if((m == 5 && d >= 22) || (m == 6 && d <= 21)) {
				System.out.print("gemini");
			}
			else if((m == 6 && d >= 22) || (m == 7 && d <= 22)) {
				System.out.print("cancer");
			}
			else if((m == 7 && d >= 23) || (m == 8 && d <= 21)) {
				System.out.print("leo");
			}
			else if((m == 8 && d >= 22) || (m == 9 && d <= 23)) {
				System.out.print("virgo");
			}
			else if((m == 9 && d >= 24) || (m == 10 && d <= 23)) {
				System.out.print("libra");
			}
			else if((m == 10 && d >= 24) || (m == 11 && d <= 22)) {
				System.out.print("scorpio");
			}
			else if((m == 11 && d >= 23) || (m == 12 && d <= 22)) {
				System.out.print("sagittarius");
			}
			else {
				System.out.print("capricorn");
			}
			System.out.println();
		}
	}

}