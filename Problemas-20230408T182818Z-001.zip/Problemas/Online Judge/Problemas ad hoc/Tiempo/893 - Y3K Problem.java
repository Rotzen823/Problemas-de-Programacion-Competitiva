import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int dias, d, m, a;
		Scanner sc = new Scanner(System.in);
		while(true) {
			dias = sc.nextInt(); d = sc.nextInt(); m = sc.nextInt(); a = sc.nextInt();
			
			if(dias == 0 && d == 0 && m == 0 && a == 0) {
				break;
			}
			
			Calendar c = GregorianCalendar.getInstance();
			c.set(a, m - 1, d + dias);
			SimpleDateFormat sdf = new SimpleDateFormat("d M yyyy");
			System.out.println(sdf.format(c.getTime()));
		}
	}

}