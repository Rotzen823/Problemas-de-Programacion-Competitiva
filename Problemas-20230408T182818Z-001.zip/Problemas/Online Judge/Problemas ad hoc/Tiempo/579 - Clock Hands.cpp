#include <bits/stdc++.h>
 
using namespace std;

int main() {
    double h, m;
    while(scanf("%lf:%lf", &h, &m), !(h == 0 && m == 0)){
        if(h == 12){
            h = 0;
        }

        double angH, angM;
        h += (m / 60);

        angH = (h * 180) / 6;
        angM = (m * 180) / 30;
        
        double res = angH - angM;
        if(res < 0){
            res = -res;
        }

        res = min(res, 360 - res);
        printf("%0.3lf\n", res);
    }
    
    return 0;
}