#include <bits/stdc++.h>
 
using namespace std;

int main() {
    int n;
    while(scanf("%d", &n), !(n == 0)){
        int pag = n / 4;
        if(n % 4 != 0){
            pag++;
        }
        pag *= 2;
        int mat[pag][2];
        int p = 1;
        bool bandera = true;
        for(int k = 0; k < pag; k++){
            if(bandera){
                mat[k][1] = p > n ? 0 : p++;
                bandera = false;
            }
            else{
                mat[k][0] = p > n ? 0 : p++;
                bandera = true;
            }
        }

        for(int k = pag - 1; k >= 0; k--){
            if(bandera){
                mat[k][1] = p > n ? 0 : p++;
                bandera = false;
            }
            else{
                mat[k][0] = p > n ? 0 : p++;
                bandera = true;
            }
        }

        printf("Printing order for %d pages:\n", n);
        for(int k = 0; k < pag; k++){
            if(mat[k][0] == 0 && mat[k][1] == 0){
                continue;
            }

            printf("Sheet %d, ", (k / 2 + 1));
            if(k & 1){
                printf("back : ");
            }
            else{
                printf("front: ");
            }

            if(mat[k][0] == 0){
                printf("Blank, ");
            }
            else{
                printf("%d, ", mat[k][0]);
            }

            if(mat[k][1] == 0){
                printf("Blank\n");
            }
            else{
                printf("%d\n", mat[k][1]);
            }
        }
    }
    
    return 0;
}