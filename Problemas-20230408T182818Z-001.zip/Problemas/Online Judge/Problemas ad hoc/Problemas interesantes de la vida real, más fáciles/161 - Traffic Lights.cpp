#include <bits/stdc++.h>
#define MAX 1000
 
using namespace std;

int nums[MAX];
int n = 0;

bool verde(int x, int y){
    int c = x / y;
    if(c & 1){
        return false;
    }
    else if(x % y >= (y - 5)){
        return false;
    }

    return true;
}

void hora(int t){
    int h = t / 3600;
    t %= 3600;
    int m = t / 60;
    int s = t % 60;

    printf("0%d:", h);
    if(m < 10){
        printf("0");
    }
    printf("%d:", m);

    if(s < 10){
        printf("0");
    }
    printf("%d\n", s);
}

int main() {
    int x;
    int men = 100;
	while(scanf("%d", &x)){

        if(x == 0 && n == 0){
            scanf("%d %d", &x, &x);
            break;
        }
        else if(x == 0){
            int t = men * 2;
            bool bol = true;
            while(bol && t <= 18000){
                bol = false;
                for(int k = 0; k < n; k++){
                    if(!verde(t, nums[k])){
                        int c = t / nums[k];
                        if(c & 1){
                            t = nums[k] * (c + 1);
                        }
                        else{
                            t = nums[k] * (c + 2);
                        }
                        bol = true;
                        break;
                    }
                }
            }

            if(t > 18000){
                printf("Signals fail to synchronise in 5 hours\n");
            }
            else{
                hora(t);
            }
            n = 0;
            men = 100;
            continue;
        }

        nums[n++] = x;
        men = min(men, x);
    }
    
    return 0;
}