#include <bits/stdc++.h>
 
using namespace std;

int main() {
    int n;

    scanf("%d", &n);

    while(n--){
        int s, d;

        scanf("%d %d", &s, &d);

        int x, y;
        x = (s + d);
        if(x % 2 == 0){
            x /= 2;
            y = s - x;
            if(y >= 0){
                if(y > x) swap(x, y);
                printf("%d %d\n", x, y);
                continue;
            }
        }

        x = (s - d);
        if(x % 2 == 0 && x >= 0){
            x /= 2;
            y = s - x;
            if(y >= 0){
                if(y > x) swap(x, y);
                printf("%d %d\n", x, y);
                continue;
            }
        }

        printf("impossible\n");


    }
    
    return 0;
}