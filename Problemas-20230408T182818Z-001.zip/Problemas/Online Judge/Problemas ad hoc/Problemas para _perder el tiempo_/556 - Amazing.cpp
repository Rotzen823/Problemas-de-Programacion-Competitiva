#include <bits/stdc++.h>
#define MAX 100
 
using namespace std;

int n, m;
int mat[MAX][MAX];
int D[] = {0, -1, 0, 1};
int d[] = {1, 0, -1, 0};

bool pared(int x, int y){
    if(x < 0 || x >= n || y < 0 || y >= m){
        return true;
    }

    return mat[x][y];
}

int avanzar(int x, int y, int i){
    
    for(int k = 0; k < 4; k++){
        int dir = (i + k) % 4;
        int ax = x + D[dir], ay = y + d[dir];
        if(!pared(ax, ay)){
            return dir;
        }
    }
    
    return i;
}

int main() {
    
    while(scanf("%d %d", &n, &m), !(n == 0 && m == 0)){
        int block[n][m];
        int res[5] = {0};
        char ax;
        for(int k = 0; k < n; k++){
            scanf("%c", &ax);
            for(int j = 0; j < m; j++){
                scanf("%c", &ax);
                mat[k][j] = ax - '0';
                block[k][j] = 0;
                if(!mat[k][j]){
                    res[0]++;
                }
            }
        }

        int xf = n - 1, yf = 0;
        int x = xf, y = yf, dir = 0;

        do{
            //printf("%d %d\n", x, y);
            res[block[x][y]]--;
            block[x][y]++;
            res[block[x][y]]++;

            int dirD = (dir + 3) % 4;
            if(!pared(x + D[dirD], y + d[dirD])){
                dir = dirD;
            }
            else{
                dir = avanzar(x, y, dir);
            }

            x = x + D[dir];
            y = y + d[dir];

        }while(!(x == xf && y == yf));

        for(int k = 0; k < 5; k++){
            if(res[k] < 100){
                printf(" ");
                if(res[k] < 10){
                    printf(" ");
                }
            }
            printf("%d", res[k]);
        }
        printf("\n");
    }
    
    return 0;
}