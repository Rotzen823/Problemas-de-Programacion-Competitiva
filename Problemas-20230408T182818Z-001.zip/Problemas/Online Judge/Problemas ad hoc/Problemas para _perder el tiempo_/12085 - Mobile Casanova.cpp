#include <bits/stdc++.h>
 
using namespace std;

typedef unsigned long long ll;

string numero(string a, string b){
    int n = b.length();

    for(int k = 0; k < n; k++){
        if(a[k] != b[k]){
            return b.substr(k, n - k);
        }
    }
}

string sumar1(string s){
    int n = s.length();
    int ac = 1;
    for(int k = n - 1; k >= 0 && ac > 0; k--){
        int num = (s[k] - '0') + ac;
        ac = num / 10;
        s[k] = (num % 10) + '0';
    }

    return s;
}

int main() {
    int n, caso = 1;
    while(scanf("%d", &n), !(n == 0)){
        string in, fin, x;

        printf("Case %d:\n", caso++);
        cin >> in;
        fin = in;

        while(--n){
            cin >> x;

            if(sumar1(fin) == x){
                fin = x;
                continue;
            }
            else if(in == fin){
                cout << in << "\n";
            }
            else{
                cout << in << "-" << numero(in, fin) << "\n";
            }

            in = fin = x;
        }

        if(in == fin){
            cout << in << "\n";
        }
        else{
            cout << in << "-" << numero(in, fin) << "\n";
        }
        printf("\n");
    }
    
    return 0;
}