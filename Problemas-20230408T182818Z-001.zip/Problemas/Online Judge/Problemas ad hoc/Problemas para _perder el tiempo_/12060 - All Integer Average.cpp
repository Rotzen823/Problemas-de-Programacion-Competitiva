#include <bits/stdc++.h>
 
using namespace std;

int cif(int a){
    int x = 1;
    while(a > 0){
        x *= 10;
        a /= 10;
    }

    return x / 10;
}

int main() {
    int n, caso = 1;
    
    while(scanf("%d", &n), !(n == 0)){
        int sum = 0;
        for(int k = 0; k < n; k++){
            int x;
            scanf("%d", &x);
            sum += x;
        }

        int a, b, c;
        bool negative = false;
        if(sum < 0){
            negative = true;
            sum = -sum;
        }
        a = sum / n;
        b = sum % n;
        c = n;
        int mcd = __gcd(b, c);
        b /= mcd;
        c /= mcd;

        int ax = cif(c);
        int ax2 = ax;

        int ax3 = cif(a);
        int ax4 = ax3;
        
        printf("Case %d:\n", caso++);

        if(b == 0){
            if(negative){
                printf("- ");
            }
            printf("%d\n", a);
            continue;
        }

        if(negative){
            printf("  ");
        }
        while(ax3 > 0){
            printf(" ");
            ax3 /= 10;
        }

        while(b < ax){
            printf(" ");
            ax /= 10;
        }
        printf("%d\n", b);

        if(negative){
            printf("- ");
        }
        if(a > 0){
            printf("%d", a);
        }
        while(ax2 > 0){
            printf("-");
            ax2 /= 10;
        }
        printf("\n");

        if(negative){
            printf("  ");
        }
        while(ax4 > 0){
            printf(" ");
            ax4 /= 10;
        }
        printf("%d\n", c);
    }
    
    return 0;
}