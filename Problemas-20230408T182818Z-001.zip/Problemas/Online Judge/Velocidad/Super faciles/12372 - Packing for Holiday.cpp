#include <bits/stdc++.h>

using namespace std;

int main(){

	int n, a, b, c;

	scanf("%d", &n);

	for(int k = 1; k <= n; k++){
		scanf("%d %d %d", &a, &b, &c);

		if(a > 20 || b > 20 || c > 20){
			printf("Case %d: bad\n", k);
		}
		else{
			printf("Case %d: good\n", k);
		}
	}

	return 0;
}