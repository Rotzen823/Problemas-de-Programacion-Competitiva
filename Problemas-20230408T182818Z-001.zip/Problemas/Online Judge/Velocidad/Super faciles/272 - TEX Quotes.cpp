#include <bits/stdc++.h>

using namespace std;

int main(){
	char ax;
	bool ban = true;

	while(scanf("%c", &ax) != EOF){
		if(ax == '"'){
			if(ban){
				printf("``");
				ban = false;
			}
			else{
				printf("''");
				ban = true;
			}
		}
		else{
			printf("%c", ax);
		}
	}
	

	return 0;
}