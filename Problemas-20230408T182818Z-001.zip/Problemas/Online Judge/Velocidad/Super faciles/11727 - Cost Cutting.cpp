#include <bits/stdc++.h>

using namespace std;

int main(){

	int n, a, b, c, res;

	scanf("%d", &n);

	for(int k = 1; k <= n; k++){
		scanf("%d %d %d", &a, &b, &c);

		if(a > b){
			if(b > c){
				res = b;
			}
			else if(a > c){
				res = c;
			}
			else{
				res = a;
			}
		}
		else{
			if(a > c){
				res = a;
			}
			else if(b > c){
				res = c;
			}
			else{
				res = b;
			}
		}
		
		printf("Case %d: %d\n", k, res);
	}

	return 0;
}