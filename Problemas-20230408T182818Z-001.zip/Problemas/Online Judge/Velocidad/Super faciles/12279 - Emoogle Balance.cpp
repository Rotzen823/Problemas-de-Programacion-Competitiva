#include <bits/stdc++.h>
 
using namespace std;

int main() {
    int n, caso = 1;
    
    while(scanf("%d", &n), (n != 0)){
        int c = 0;
        while(n--){
            int x;
            scanf("%d", &x);
            if(x){
                c++;
            }
            else{
                c--;
            }
        }
        printf("Case %d: %d\n", caso, c);
        caso++;
    }

    return 0;
}