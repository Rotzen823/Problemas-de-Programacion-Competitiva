#include <bits/stdc++.h>

using namespace std;

int dif(int a, int b, bool dir){
	int x = a - b;

	if(x < 0){
		x += 40;
	}

	int res = x * 9;

	if(dir){
		res = 360 - res;
	}
	return res;
}

int main(){
	
	int n;

	scanf("%d", &n);

	long long a, b;

	while(n--){
		scanf("%lld", &a);
		//315x + 36962
		a = 315 * a + 36962;
		if(a < 0){
			a = -a;
		}
		b =(a % 100) / 10;
		printf("%lld\n", b);
	}
	

	return 0;
}