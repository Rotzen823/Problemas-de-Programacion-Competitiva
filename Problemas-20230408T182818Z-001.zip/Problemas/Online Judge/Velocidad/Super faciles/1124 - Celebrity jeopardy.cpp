#include <bits/stdc++.h>

using namespace std;

int main(){
	char ax;

	while(scanf("%c", &ax) != EOF){
		printf("%c", ax);
	}
	

	return 0;
}